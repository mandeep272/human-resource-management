from django.apps import AppConfig


class EmployeeInformationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'employee_information'
